# Migrator Distribution

This ZIP file contains a source-only distribution of the Migrator (UCX) Unity Catalog migration toolkit, renamed for easy import into Databricks workspaces.

## Quick Start

1. **Import into Databricks:**
   - Go to Workspace → Import in your Databricks UI
   - Choose "Source" format and upload this ZIP file
   - The files will be extracted to `/Workspace/migrator_dist/`

2. **Run the installation script:**
   - Open `install_migrator.py` in a Databricks notebook
   - Run the script and follow the prompts
   - This will set up the assessment workflows in your workspace

3. **Use in your notebooks:**
   ```python
   import sys
   sys.path.insert(0, '/Workspace/migrator_dist')
   
   import migrator
   # migrator.assessment is now available
   ```

## What's Included

- **migrator/** - Main package with all UCX functionality renamed
- **databricks/labs/migrator/** - Full source code
- **install_migrator.py** - Installation script
- **README.md** - This file

## Requirements

- Databricks Premium or Enterprise workspace
- Workspace Admin privileges
- PRO or Serverless SQL Warehouse
- Python 3.10+ (automatically available in DBR)

## Installation Options

### Option 1: Add to cluster libraries (Recommended)
1. Go to your cluster configuration
2. Libraries → Install New → Upload → Python
3. Upload this ZIP file
4. Restart cluster
5. All notebooks on this cluster can now `import migrator`

### Option 2: Per-notebook import
```python
import sys
sys.path.insert(0, '/Workspace/migrator_dist')
import migrator
```

## One-liner Usage

After setup, you can install assessment workflows with:

```python
import migrator
from databricks.sdk import WorkspaceClient

migrator.assessment(WorkspaceClient()).run()
```

## Dependencies

This distribution includes all UCX source code but requires external dependencies. The installation notebook will automatically install these, but you can also install them manually:

### Required Packages:
- `databricks-sdk>=0.58.0,<0.59.0` - Databricks SDK
- `databricks-labs-lsql>=0.16.0,<0.17.0` - SQL backends and dashboards  
- `databricks-labs-blueprint>=0.11.0,<0.12.0` - Installation and utilities framework
- `PyYAML>=6.0.0,<6.1.0` - YAML configuration handling
- `sqlglot>=26.7.0,<27.1.0` - SQL parsing and analysis
- `astroid>=3.3.0,<3.4.0` - Python code analysis

### Manual Installation:
```python
%pip install databricks-sdk>=0.58.0,<0.59.0 databricks-labs-lsql>=0.16.0,<0.17.0 databricks-labs-blueprint>=0.11.0,<0.12.0 PyYAML>=6.0.0,<6.1.0 sqlglot>=26.7.0,<27.1.0 astroid>=3.3.0,<3.4.0
dbutils.library.restartPython()
```

## Support

This is a source distribution based on the open-source UCX project. For support:
- Review the installation notebook output
- Check generated dashboards for guidance
- Consult the original UCX documentation
