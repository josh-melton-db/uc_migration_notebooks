# Azure Service Principals

Below you find the Azure service principals found by UCX in Spark configuration from:
- Clusters configurations
- Cluster policies
- Job cluster configurations
- Pipeline configurations
- Warehouse configuration
