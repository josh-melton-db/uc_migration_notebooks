/* --title 'Storage Locations' */
SELECT
  COUNT(*) AS count_total
FROM inventory.external_locations