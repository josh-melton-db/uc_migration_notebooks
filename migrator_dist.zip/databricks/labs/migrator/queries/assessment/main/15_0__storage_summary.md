## Storage Summary
-  External Locations

-  Mount Points

[documentation](https://databrickslabs.github.io/ucx/docs/reference/workflows/#assessment-workflow)
