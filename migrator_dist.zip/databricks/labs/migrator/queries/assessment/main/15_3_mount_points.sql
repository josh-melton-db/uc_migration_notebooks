/* --title 'Mount Points' --width 3 --height 6 */
SELECT
  name,
  source
FROM inventory.mounts