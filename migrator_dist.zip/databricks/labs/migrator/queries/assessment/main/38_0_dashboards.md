---
height: 4
---

# Dashboards

The table below displays the dashboards in the workspace. The dashboard queries are linted, these linting outcomes are
displayed in the tables above.
