---
height: 4
width: 1
---

Group Migration Failures
------------------------

When migrating groups, errors may occur during the migration of a particular group. Any errors that occurred while migrating groups are displayed here.
