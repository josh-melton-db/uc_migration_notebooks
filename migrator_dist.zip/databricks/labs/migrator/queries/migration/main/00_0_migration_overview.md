---
height: 2
---

# Migration overview

[Quick link to the table migration documentation](https://databrickslabs.github.io/ucx/docs/process/#table-migration-process)
