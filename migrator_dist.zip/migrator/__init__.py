"""
Migrator - Unity Catalog Migration Toolkit

A renamed version of UCX for easy import into Databricks workspaces.
"""

# Main installer for assessment workflows
from databricks.labs.migrator.install import WorkspaceInstaller as assessment

# Common utilities
from databricks.labs.migrator.install import WorkspaceInstaller
from databricks.labs.migrator.config import WorkspaceConfig

__all__ = ['assessment', 'WorkspaceInstaller', 'WorkspaceConfig']
